<?php
namespace CaptureTheFlag;

use pocketmine\plugin\PluginBase;
use LbCore\LbCore;
use CaptureTheFlag\task\CaptureTheFlagTournamentTick;
use CaptureTheFlag\task\CaptureTheFlagNotificationTick;
use CaptureTheFlag\data\FlagData;
use CaptureTheFlag\CaptureTheFlagEventListener;
use CaptureTheFlag\CaptureTheFlagGame;
use pocketmine\utils\TextFormat;
use LbCore\language\Translate;
use GametypeStatues\GametypeStatues;
use VipLounge\VIPLounge;
use Kits\Kit;

class CaptureTheFlag extends PluginBase{
    
	protected $listener;
	protected $lbcore;
	protected $game;
	public $lang;

    /**
     * Logic to be run when plugin is enabled.
	 * This is CTF specific
	 * Initialize components (lang pack, repeating tasks, etc)
     */
	public function onEnable(){
		$this->getLogger()->info("Starting Lifeboat CtF Server...");
		$this->lbcore = LbCore::getInstance();
		$flagData = new FlagData();
		$this->game = new CaptureTheFlagGame($this, $flagData->getFlagData());
		$this->listener = new CaptureTheFlagEventListener($this, $this->game);
		$this->lang = Translate::getInstance();
		$this->lang->createTranslations('CaptureTheFlag\\language\\');
		$this->getServer()->getPluginManager()->registerEvents($this->listener, $this);
		$this->getServer()->getNetwork()->setName(TextFormat::AQUA . "Life" . TextFormat::RED . "Boat " . TextFormat::BOLD . TextFormat::GOLD . "CTF");
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new CaptureTheFlagTournamentTick($this, $this->game), 20);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new CaptureTheFlagNotificationTick($this, $this->game), 10);
		$this->getServer()->setConfigInt("max-players", 70);
		$this->getServer()->setConfigBool("announce-player-achievements", false);
		try {
			VIPLounge::enable($this);
			VIPLounge::getInstance()->initLoungeGuards();
		} catch (Exception $e) {
			echo 'EXCEPTION: Problem with starting VIPLounge'.PHP_EOL;
			echo 'EXCEPTION: '.$e->getMessage().PHP_EOL;
		}
		GametypeStatues::getInstance()->enable("CaptureTheFlag");
		// enable kits
		Kit::enable($this);
		//enable pets
		$this->getServer()->getPluginManager()->registerEvents(new \Pets\PetsManager($this), $this);
		$this->getLogger()->info("Done!");
	}

    /**
     * When the server shuts down
     */
	public function onDisable(){

	}

}
