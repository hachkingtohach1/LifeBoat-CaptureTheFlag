<?php

namespace CaptureTheFlag;

use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;

/**
 * Contains logic of the CtF game
 */
class CaptureTheFlagGame {

	protected $flagData;
	protected $plugin;
	protected $level;
	protected $teams = ["red" => [], "blue" => []];
	protected $inGamePlayers = [];
	protected $startTimer = -1;
	protected $reinitTimer = -1;
	protected $kills = ["red" => 0, "blue" => 0];
	protected $placedBlocks;
	protected $isStart = false;
	protected $startTime = 0;

	/*
	 * Initialize CtF game configs
	 */
	public function __construct($plugin, $flagData) {
		$this->plugin = $plugin;
		$this->flagData = $flagData;
		$this->initPlacedBlocks();
		$this->level = $this->plugin->getServer()->getDefaultLevel();
		$this->level->setTime(6000);
		$this->level->stopTime();
		$this->level->freezeMap();
	}
	
	/*
	 * Reinitialize teams flags
	 */
	public function initPlacedBlocks(){
		$this->placedBlocks = [
			'red' => [
				'redPlaced1' => false, /** Black Wool **/
				'redPlaced2' => false, /** Orange Wool **/
			],
			'blue' => [
				'bluePlaced1' => false, /** Lime Wool **/
				'bluePlaced2' => false, /** Purple Wool **/
			],
		];
	}
	
	/**
     * Called when a player quits or is kicked, remove player from game
     */
    public function removePlayer($player){        
		unset($this->teams["red"][$player->getId()]);
		unset($this->teams["blue"][$player->getId()]);
		unset($this->inGamePlayers[$player->getId()]);
    }
	
	/**
     * Sets the hologragraphic/floating text particles at the entrance of the spawn rooms to explain gameplay
     */
    public function setGameExplanation($player){
        $gameExplanation = $this->plugin->lang->getTranslatedString($player->language, "GAME_EXPLANATION");
        $flagExplanation = $this->plugin->lang->getTranslatedString($player->language, "FLAG_EXPLANATION");

		$entranceCords = $this->flagData["textParticles"]["entrance"][$player->getTeam()];
		$flagStand = $this->flagData["textParticles"]["aboveFlags"][$player->getTeam()];

		$entranceEntity = new FloatingTextParticle(new Vector3($entranceCords["x"], $entranceCords["y"], $entranceCords["z"]), "", $gameExplanation);
        $entranceText = $entranceEntity->encode();
        $player->dataPacket($entranceText[0]); 
		
		$flagEntity = new FloatingTextParticle(new Vector3($flagStand["x"], $flagStand["y"], $flagStand["z"]), "", $flagExplanation);
        $flagText = $flagEntity->encode();
        $player->dataPacket($flagText[0]);
    }
	
	/**
	 * Joins player to game when he authorized
	 */
	public function joinPlayer($player){
		$player->getInventory()->clearAll();
		$player->getInventory()->sendContents($player);
		$team = (count($this->teams["red"]) > count($this->teams["blue"]))? "blue" : "red";
        $player->setTeam($team);
		$this->teams[$team][$player->getId()] = $player;
		$this->inGamePlayers[$player->getId()] = $player;
		if($this->isStart){
			$spawnPos = $this->flagData["spawnCoords"][$player->getTeam()];
			$spawnPos["x"] = $spawnPos["x"] + (rand(0,2) * pow(-1, rand(1,2)));
			$spawnPos["z"] = $spawnPos["z"] + (rand(0,2) * pow(-1, rand(1,2)));
			$player->setSpawn(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
			$player->teleport(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
            if($player->isVip()){
                $player->giveVipKit();
            }else{
                $player->giveSpawnKit();
            }
		}
	}
	
	/**
	 * Initialize game params, clear map, etc
	 */
	public function initGame(){
		$this->isStart = false;
		$this->startTimer = 10;
		$this->inGamePlayers = [];
		$this->teams["red"] = [];
		$this->teams["blue"] = [];	
		$this->initPlacedBlocks();
		$this->kills = ["red" => 0, "blue" => 0];
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {	
            if($player->getTeam() != ""){
                $player->getInventory()->clearAll();
                $player->getInventory()->sendContents($player);
                $player->setTeam("");
                $player->setStateInLobby();
                $spawnLocation = $this->flagData["lobbyCoords"];
                $player->setSpawn(new Vector3($spawnLocation["x"], $spawnLocation["y"], $spawnLocation["z"]));
                $player->teleport(new Vector3($spawnLocation["x"], $spawnLocation["y"], $spawnLocation["z"]));
                if(!$player->isDead()){
                    $player->setHealth($player->getMaxHealth());
                    $player->setFood(20);
                }
            }
		}
		$this->level->unfreezeMap();
		$this->startTime = 0;
	}
	
	/**
     * Checks the $this->game->blocksPlaced array for the given team color and sees if both {$teamColor}Placed1 are true. If
     * they are not return false, if they are return true (team wins)
     */
    public function checkWinningBlocks($team){
        foreach($this->placedBlocks[$team] as $placed) {
            if($placed){
                continue;
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * Sends game over announcement and winner announcement to each player in the server and resets the game
     */
    public function won($team) {
        foreach($this->plugin->getServer()->getOnlinePlayers() as $recipient) {
			$recipient->sendMessage(TextFormat::GRAY."-----------------------------");
			$recipient->sendLocalizedMessage("WON_MATCH", array(constant('pocketmine\utils\TextFormat::' . strtoupper($team)).ucfirst($team)));
			$recipient->sendMessage(TextFormat::GRAY."-----------------------------");
        }
		$this->reinitTimer = 10;        
    }

    /**
     * Method called when a team places their first flag. It sends out a message to each player.
     */
    public function oneFlagPlaced($team){
        foreach($this->plugin->getServer()->getOnlinePlayers() as $recipient) {
			$recipient->sendMessage(TextFormat::GRAY."-----------------------------");
			$recipient->sendLocalizedMessage("FIRST_FLAG", array(constant('pocketmine\utils\TextFormat::' . strtoupper($team)).ucfirst($team)));
			$recipient->sendMessage(TextFormat::GRAY."-----------------------------");
        }
    }
	
	/*
	 * Returns start timer
	 */
	public function getStartTimer(){
		return $this->startTimer;
	}
	
	/*
	 * Decrements start timer
	 */
	public function decStartTimer(){
		$this->startTimer--;
	}
	
	/*
	 * Runs start timer
	 */
	public function runStartTimer(){
		$this->startTimer = 10;
	}
	
	/*
	 * Returns reInitialize game timer
	 */
	public function getReinitTimer(){
		return $this->reinitTimer;
	}
	
	/*
	 * Decrements reInitialize game timer
	 */
	public function decReinitTimer(){
		$this->reinitTimer--;
	}
	
	/*
	 * Returns kills count for specifically team
	 */
	public function getTeamKills($team){
		return $this->kills[$team];
	}
	
	/*
	 * Returns list of players in specifically team
	 */
	public function getTeamMembers($team){
		return $this->teams[$team];
	}
	
	/*
	 * Returns list of players in game
	 */
	public function getInGamePlayers(){
		return $this->inGamePlayers;
	}

	/*
	 * Returns placed flags
	 */
	public function getPlacedBlocks($team = null, $block = null){
		if($team != null && $block != null){
			return $this->placedBlocks[$team][$block];
		}else{
			return $this->placedBlocks;
		}
	}
	
	/*
	 * Sets placed flag
	 */
	public function setPlacedBlock($team, $block){
		$this->placedBlocks[$team][$block] = true;
	}
	
	/*
	 * Returns CtF flags data
	 */
	public function getFlagData($param1, $param2 = null){
		if($param2 != null){
			return $this->flagData[$param1][$param2];
		}else{
			return $this->flagData[$param1];
		}
	}
	
	/*
	 * Increments team kills
	 */
	public function incTeamKills($team){
		return $this->kills[$team]++;
	}
	
	/*
	 * Return current level
	 */
	public function getLevel(){
		return $this->level;
	}
	
	/*
	 * Return bool value, started game or not
	 */
	public function getIsStart(){
		return $this->isStart;
	}
	
	/*
	 * Sets new game state
	 */
	public function setIsStart($start){
		$this->isStart = $start;
	}
	
	/*
	 * Freeze map
	 */
	public function freezeGameMap(){
		$this->level->freezeMap();
	}
	
	/*
	 * Returns start time
	 */
	public function getStartTime(){
		return $this->startTime;
	}
	
	/*
	 * Sets new start time
	 */
	public function setStartTime($time){
		$this->startTime = $time;
	}
}
