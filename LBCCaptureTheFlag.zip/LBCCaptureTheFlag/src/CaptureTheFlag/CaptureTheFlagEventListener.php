<?php

namespace CaptureTheFlag;

use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerRespawnAfterEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use CaptureTheFlag\CaptureTheFlagPlayer;
use pocketmine\event\player\PlayerCreationEvent;
use LbCore\LbCore;
use pocketmine\event\entity\EntityExplodeEvent;
use pocketmine\utils\TextFormat;


class CaptureTheFlagEventListener extends \LbCore\LbEventListener{
	
	protected $plugin;
    protected $game;

	public function __construct($plugin, $gameManager) {
		$this->plugin = $plugin;
		$this->game = $gameManager;
		parent::__construct($plugin);
	}
	
	/**
	 * Set server name and attributes
	 */
	public function onQuery(QueryRegenerateEvent $event) {
		$lbcore = LbCore::getInstance();
		if (isset($lbcore->playerCount->ctf_players)) {
			$event->setPlayerCount($lbcore->playerCount->ctf_players);
		}
		if (isset($lbcore->playerCount->ctf_slots)) {
			$event->setMaxPlayerCount($lbcore->playerCount->ctf_slots);
		}
		$event->setServerName('{-name-:-Lifeboat Fleet-,-node-:{-type-:-WL-,-ip-:-' . $lbcore->getDomainName() . '-,-players-:' . count($this->plugin->getServer()->getOnlinePlayers()) . ',-maxplayers-:90,-tps-:' . $this->plugin->getServer()->getTicksPerSecond() . '}}');
	}
	
	/**
	 * Set CaptureTheFlagPlayer instead of LbPlayer
	 */
	public function onPlayerCreation(PlayerCreationEvent $event) {
		$event->setPlayerClass(CaptureTheFlagPlayer::class);
	}
	
	/**
	 * Set recipients to players messages
	 */
	public function onPlayerChat(PlayerChatEvent $event) {
		parent::onPlayerChat($event);
        if ($event->isCancelled()) {
			return;
		}
		$player = $event->getPlayer();
		$recipients = [];
        if($player->isAuthorized()){
            if($player->getTeam() == ""){
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $p){
                    if($p->getTeam() == ""){
                        $recipients[] = $p;
                    }
                }
                $event->setCancelled(true);
                $message = $event->getMessage();
                $newMessage = TextFormat::YELLOW . str_replace(TextFormat::WHITE, TextFormat::YELLOW, $player->getDisplayName()) . "§b: " . TextFormat::WHITE . $message;
                foreach ($recipients as $recipient) {
                    $recipient->sendMessage($newMessage);
                }
            }else{
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $p){
                    if($p->getTeam() != ""){
                        $recipients[] = $p;
                    }
                }
                $event->setRecipients($recipients);
            }
        }
	}

    /**
     * Called when player joins the game.
     */
	public function onPlayerLogin(PlayerLoginEvent $event) {
		parent::onPlayerLogin($event);
		$player = $event->getPlayer();
		$player->getInventory()->clearAll();
		$spawnPos = $this->game->getFlagData("lobbyCoords");
		$spawnPos["x"] = $spawnPos["x"] + (rand(0,2) * pow(-1, rand(1,2)));
		$spawnPos["z"] = $spawnPos["z"] + (rand(0,2) * pow(-1, rand(1,2)));
		$player->setSpawn(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
		$player->teleport(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
        $player->setStateInLobby();
    }

    /**
     * Deny players to move to their flag rooms or enemy base
     */
    public function onPlayerMove(PlayerMoveEvent $event){
        $player = $event->getPlayer();
		$x = round($player->getX(), 0);
		$y = round($player->getY(), 0);
		$z = round($player->getZ(), 0);

		//stay away from map signs
        if(($player->getZ() >= 1967 &&  $player->getZ() <= 1969) && ($player->getX() >= -1654 && $player->getX() <= -1652)) {
            $player->setMotion(new Vector3(0, 0.2, -0.6));
            return;
        }
        //fly from red tiles in lobby
        if ($player->getZ() > 1929 && $player->getZ() < 1931) {
            if ($player->getX() > -1646 && $player->getX() < -1644) {
                $player->setMotion(new Vector3(1.6, 0.2, 0));
            }
            if ($player->getX() > -1662 && $player->getX() < -1660) {
                $player->setMotion(new Vector3(-1.6, 0.2, 0));
            }
        }
        if ($player->getX() > -1654 && $player->getX() < -1652) {
            if ($player->getZ() > 1937 && $player->getZ() < 1939) {
                $player->setMotion(new Vector3(0, 0.2, 1.6));
            }
        }
		if($player->isAuthorized() && $player->getTeam() != "" && $this->game->getIsStart() && $this->game->getStartTimer() < 0 && $this->game->getReinitTimer() < 0){			
			/** Check whether or not player is allowed to enter a flag room **/
			foreach ($this->game->getFlagData("flagRooms") as $room) {
				if (($x >= $room["xStart"] && $x <= $room["xStop"]) && ($z >= $room["zStart"] && $z <= $room["zStop"])){
					if($player->getTeam() != $room["team"]) {
						$event->setCancelled(true);
						$player->teleport(new Vector3($x, $y, ($z > 0 ? $z - 3 : $z + 3)));
					}
				}
			}
			
			/** Check whether or not a player is to enter spawn/flag placing area **/
			 foreach ($this->game->getFlagData("spawnRooms") as $room) {
				if (($x >= $room["xStart"] && $x <= $room["xStop"]) && ($z >= $room["zStart"] && $z <= $room["zStop"])) {
					if ($player->getTeam() != $room["team"]) {
						$event->setCancelled(true);
						$player->teleport(new Vector3($x, $y, ($z > 0 ? $z - 3 : $z + 3)));
					}
				}
			}
		}
    }

    /**
     * This method mainly checks whether or not the supply chest in the flag room can be opened or not. The rooms are off
     * limits to the team who is defending it. If they somehow get in this prevents them from getting the chest.
     */
    public function onPlayerInteract(PlayerInteractEvent $event){		
        $player = $event ->getPlayer();
		$block = $event->getBlock();
        if($block->getId() == Block::BED_BLOCK){
            return;
        }
        if(!$player->isAuthorized() || $player->getTeam() == "" || !$this->game->getIsStart() || $player->getState() == $player::IN_LOBBY){
			if($block->getX() == -1653 && $block->getY() == 37 && $block->getZ() == 1967){
                if($player->isAuthorized()){
                    if($player->getTeam() == ""){
                        $this->game->joinPlayer($player);
                        $player->sendLocalizedMessage("JOINED_TEAM", array($player->getTeam()), constant('pocketmine\utils\TextFormat::' . strtoupper($player->getTeam())));
                        $this->game->setGameExplanation($player);
                    }
                }else{
                    if ($player->isRegistered()) {
                        $player->sendLocalizedMessage('LOGIN_BEFORE_JOIN');
						return;
					} else {
						$player->sendLocalizedMessage('REGISTER_BEFORE_JOIN');
						return;
					}
                }
            }
            $event->setCancelled();
			return;
		}
		if($player->isAuthorized()){
			$x = $block->x;
			$y = $block->y;
			$z = $block->z;
			foreach($this->game->getFlagData("chests") as $chest){
				if ($chest["x"] == $x && $chest["y"] == $y && $chest["z"] == $z && $chest["team"] != $player->getTeam()){
					$event->setCancelled(true);
				}
			}
		}
    }

	/**
	 * Set drop from players
	 */
    public function onEntityDeath(EntityDeathEvent $event) {
		$drops = $event->getDrops();
		$newDrops = [];
		$blacklist = array(Item::STONE_SWORD,Item::STONE_PICKAXE,Item::BOW,Item::STONE_AXE,Item::STONE_SHOVEL);
		foreach($drops as $drop) {
			$id = $drop->getId();
			if(!in_array($id, $blacklist)){
				$newDrops[] = $drop;
			}
		}
		$event->setDrops($newDrops);
	}
	
	/*
	 * Show specifically messages for player and his killer, increment team kills
	 */
	public function onPlayerDeath(PlayerDeathEvent $event) {
        $player = $event->getEntity();
        $attacker = false;
        if(!$player instanceof CaptureTheFlagPlayer){
			return false;
		}
		$event->setDeathMessage("");
        $attackerevt = $player->getLastDamageCause();
        if($attackerevt instanceof EntityDamageByEntityEvent) {
            $attacker = $attackerevt->getDamager();
            if($attacker instanceof CaptureTheFlagPlayer) {
                $player->sendLocalizedMessage("YOU_WERE_KILLED", array($attacker->getDisplayName()));
                $attacker->sendLocalizedMessage("YOU_KILLED", array($player->getDisplayName()));
                $this->game->incTeamKills($attacker->getTeam());
            }
        }
	}

    /**
     * Called when player respawns, puts the player back in the right spawn area.
     */
	public function onPlayerRespawn(PlayerRespawnEvent $event) {		
		$player = $event->getPlayer();
		$level = $this->game->getLevel();
		if($player->isAuthorized() && $player->getTeam() != ""){
			$spawnPos = $this->game->getFlagData("spawnCoords", $player->getTeam());				
		}else{
			$spawnPos = $this->game->getFlagData("lobbyCoords");		
		}
		$spawnPos["x"] = $spawnPos["x"] + (rand(0,2) * pow(-1, rand(1,2)));
		$spawnPos["z"] = $spawnPos["z"] + (rand(0,2) * pow(-1, rand(1,2)));
		$event->setRespawnPosition(new Position(0, 104, -121));
		$event->setRespawnPosition(new Position($spawnPos["x"], $spawnPos["y"], $spawnPos["z"], $level));
	}
	
	/*
	 * Sets wip kit for player after respawn
	 */
	public function onPlayerAfterRespawn(PlayerRespawnAfterEvent $event) {	
		$player = $event->getPlayer();
        if($player->getTeam() != ""){
            if($this->game->getIsStart()){
                if($player->isVip()){
                    $player->giveVipKit();
                }else{
                    $player->giveSpawnKit();
                }
            }
        }
	}
	
	/*
	 * Dont let TNT to break the map
	 */
	public function onEntityExplode(EntityExplodeEvent $event){
		$event->setBlockList([]);
	}

	/**
	 * Deny players to attacks their teammates
	 */
	public function onEntityDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();
		if($event instanceof EntityDamageByEntityEvent && $player instanceof CaptureTheFlagPlayer){
			$attacker = $event->getDamager();
			if($attacker instanceof CaptureTheFlagPlayer) {
				if($this->game->getStartTimer() >= 0 || $this->game->getReinitTimer() >= 0 || $attacker->getTeam() == $player->getTeam() || $attacker->getTeam() == "" || $player->getTeam() == "") {
					if($player->getTeam() != ""){
                        $flagsData = $this->game->getFlagData("winningBlocks", "team");
                        $flagsPlaces = $flagsData[$player->getTeam()];
                        foreach ($flagsPlaces as $place){
                            if(($player->getX() > $place["x"] - 1 && $player->getX() < $place["x"] + 1) &&
                               ($player->getY() > $place["y"] - 2 && $player->getY() < $place["y"] + 1) &&
                               ($player->getZ() > $place["z"] - 1 && $player->getZ() < $place["z"] + 1)){
                                return;
                            }
                        }
                    }
                    
                    $event->setCancelled(true);
				}
			}
		}
	}

	/**
	 * Remove player from team when he lefts the game
	 */
	public function onPlayerQuit(PlayerQuitEvent $event){
		$player = $event->getPlayer();
		$this->game->removePlayer($event->getPlayer());
	}

    /**
     * Deny players to break blocks in the spawn areas.
     */
	public function onBlockBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();
		if(!$player->isAuthorized() || $player->getState() === CaptureTheFlagPlayer::IN_LOBBY || $this->game->getStartTimer() > 0 || !$this->game->getIsStart()){
			$event->setCancelled();
			return;
		}
		$block = $event->getBlock();
		$x = $block->x;
		$y = $block->y;
		$z = $block->z;
		
		$room = $this->game->getFlagData("spawnRooms", $player->getTeam());
		if($x >= $room["xStart"] && $x <= $room["xStop"] && $z >= $room["zStart"] && $z <= $room["zStop"]){
			$isFlag = false;
			$winningBlocks = $this->game->getFlagData("winningBlocks", "team");
			foreach($winningBlocks[$player->getTeam()] as $winningBlock){
				if($winningBlock["x"] == $x && $winningBlock["y"] == $y && $winningBlock["z"] == $z){
					$isFlag = true;
					break;
				}
			}
			if(!$isFlag){
				$player->sendLocalizedMessage("CANT_BREAK_BLOCK");
				$event->setCancelled();
			}
		}
		
		foreach($this->game->getFlagData("flagRooms") as $room){
			if($x >= $room["xStart"] && $x <= $room["xStop"] && $z >= $room["zStart"] && $z <= $room["zStop"]){
				if($block->getId() != Block::COBWEB){
					$player->sendLocalizedMessage("CANT_BREAK_BLOCK");
					$event->setCancelled();
				}
			}
		}
		
		if($event->getBlock()->getId() === Block::COBWEB){
			$this->game->getLevel()->setBlock(new Vector3($x, $y, $z), new Block(Block::AIR));
		}
	}

    /**
     * When a block is placed check the players team, the block that is placed, and where it is placed. It loops
     * through $winningBlocks array in 'data/FlagData.php' and if the team, type of wool, and coordinates of wool
     * match then $this->game->placedBlocks is updated. If the team have placed both blocks in their
     * appropriate places then that teams wins and the game is over.
     */
	public function onBlockPlace(BlockPlaceEvent $event){
		$player = $event->getPlayer();
		if(!$player->isAuthorized() || $player->getState() === CaptureTheFlagPlayer::IN_LOBBY || $this->game->getStartTimer() > 0 || !$this->game->getIsStart()){
			$event->setCancelled();
			return;
		}
		$block = $event->getBlock();
		$x = $block->x;
        $y = $block->y;
		$z = $block->z;
        $blockName = $block->getName();
        $playerTeam = $player->getTeam();
        $winningBlocks = $this->game->getFlagData("winningBlocks");
		$placedBLocks = $this->game->getPlacedBLocks();
        $canPlace = false;
        $i = 1;
		if($this->game->getStartTimer() < 0 && $this->game->getReinitTimer() < 0 && isset($winningBlocks['team'][$playerTeam]) && is_array($winningBlocks['team'][$playerTeam])){
			foreach($winningBlocks["team"][$playerTeam] as $placed){
				$alreadyPlaced = $playerTeam."Placed".$i;
				if($placedBLocks[$playerTeam][$alreadyPlaced] == false){
					if($placed["x"] == $x && $placed["y"] == $y && $placed["z"] == $z && $placed["name"] == $blockName){
						$canPlace = true;
						$this->game->setPlacedBlock($playerTeam, $alreadyPlaced);
						$bothPlaced = $this->game->checkWinningBlocks($playerTeam);
						if($bothPlaced){
							/** If both blocks have been placed, end the game **/
							$this->game->won($playerTeam);
						} else {
							/** If both blocks have not been placed, send an announcement that one have been **/
							$this->game->oneFlagPlaced($playerTeam);
						}
					}
				}
				$i++;
			}
		}
		
		$flags = [
			15 => "Black Wool",
			1 => "Orange Wool",
			5 => "Lime Wool",
			10 => "Purple Wool"
		];
		$room = $this->game->getFlagData("spawnRooms", $player->getTeam());
		if($x >= $room["xStart"] && $x <= $room["xStop"] && $z >= $room["zStart"] && $z <= $room["zStop"]){
			$isRightFlag = false;
			$winningBlocks = $this->game->getFlagData("winningBlocks", "team");
			foreach($winningBlocks[$player->getTeam()] as $winningBlock){
				if($winningBlock["x"] == $x && $winningBlock["y"] == $y && $winningBlock["z"] == $z){
					if($block->getId() == 35 && $flags[$block->getDamage()] == $winningBlock["name"]){
						$isRightFlag = true;
						break;
					}
				}
			}
			if(!$isRightFlag){
				$player->sendLocalizedMessage("CANT_PLACE_BLOCK");
				$event->setCancelled();
			}
		}
		
		foreach($this->game->getFlagData("flagRooms") as $room){
			if($x >= $room["xStart"] && $x <= $room["xStop"] && $z >= $room["zStart"] && $z <= $room["zStop"]){
				$player->sendLocalizedMessage("CANT_PLACE_BLOCK");
				$event->setCancelled();
			}
		}
    }
}