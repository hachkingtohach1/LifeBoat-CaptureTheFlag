<?php

namespace CaptureTheFlag\data;

/**
 * Holds important coordinate information for each map that is played. Will expand when more maps are added. Enables
 * multiple tournaments on the same server and world with same logic just different coordinates.
 */
 class FlagData {
	 
	 protected $data = array(
		 /** Lobby spawn point **/
		"lobbyCoords" => array(
			"x" => -1653,
			"y" => 38,
			"z" => 1930
		),
		 /** Coordinates of blocks, where player should place flags **/
		"winningBlocks" => array(
			"team"=> array(
				"red" => array(
					"redPlaced1" => array("x" => -1043, "y" => 103, "z" => 1736, "name" => "Black Wool"), /** Black Wool **/
					"redPlaced2" => array("x" => -1045, "y" => 103, "z" => 1736, "name" => "Orange Wool"), /** Orange Wool **/
				),
				"blue" => array(
					"bluePlaced1" => array("x" => -1045, "y" => 103, "z" => 1537, "name" => "Lime Wool"), /** Lime Wool **/
					"bluePlaced2" => array("x" => -1043, "y" => 103, "z" => 1537, "name" => "Purple Wool"), /** Purple Wool **/
				),
			),
		),
		/** The colored block that you place the captured flags on **/
		"flagPlaceholders" => array(
			"black"  => array("x" => -1043, "y" => 102, "z" => 1736, "kickback" => "-"),
			"orange" => array("x" => -1045, "y" => 102, "z" => 1736, "kickback" => "-"),
			"lime"   => array("x" => -1045, "y" => 102, "z" => 1537, "kickback" => "+"),
			"purple" => array("x" => -1043, "y" => 102, "z" => 1537, "kickback" => "+"),
		),
		 /** Coordinates of spawn points in teams rooms **/
		"spawnCoords" => array(
			"red"  => array("x" => -1044, "y" => 103, "z" => 1750),
			"blue" => array("x" => -1044, "y" => 103, "z" => 1523)
		),
		"flagRooms" => array(
			/** xStart and zStart needs to be lowest number **/
			"black"  => array("team" => "red",  "xStart" => -1018, "xStop" => -1006, "y" => 99, "zStart" => 1527, "zStop" => 1546),
			"orange" => array("team" => "red",  "xStart" => -1082, "xStop" => -1070, "y" => 99, "zStart" => 1527, "zStop" => 1546),
			"lime"   => array("team" => "blue", "xStart" => -1082, "xStop" => -1070, "y" => 99, "zStart" => 1728, "zStop" => 1747),
			"purple" => array("team" => "blue", "xStart" => -1018, "xStop" => -1006, "y" => 99, "zStart" => 1728, "zStop" => 1747),
		),
		"chests" => array(
			"black"  => array("team" => "red",  "x" => -1012, "y" => 100, "z" => 1529),
			"orange" => array("team" => "red",  "x" => -1076, "y" => 100, "z" => 1529),
			"lime"   => array("team" => "blue", "x" => -1076, "y" => 100, "z" => 1744),
			"purple" => array("team" => "blue", "x" => -1012, "y" => 100, "z" => 1744),
		),
		/** Coordinates of spawn rooms **/
		"spawnRooms" => array(
			"red"   => array("team" => "red",   "xStart" => -1056, "xStop" => -1032, "y" => 99, "zStart" => 1726, "zStop" => 1763),
			"blue"  => array("team" => "blue",  "xStart" => -1056, "xStop" => -1032, "y" => 99, "zStart" => 1510, "zStop" => 1547),
		),
		/** Coordinates of bounds on teams rooms **/
		"spawnBound" => array(
			"red"   => array("team" => "red", "z" => 1740, "zGreaterThan" => false, "pushedBack" => 1743),
			"blue"  => array("team" => "blue","z" => 1534, "zGreaterThan" => true, "pushedBack" => 1531),
		),
		/** Coordinates of floating text with game explanation **/ 
		"textParticles" => array(
			"entrance" => array(
				"blue"   => array("team" => "blue", "x" => -1044, "y" => 108, "z" => 1530),
				"red"  => array("team" => "red", "x" => -1044, "y" => 108, "z" => 1744)
			),
			"aboveFlags" => array(
				"blue"   => array("team" => "blue", "x" => -1044, "y" => 106, "z" => 1537),
				"red"  => array("team" => "red", "x" => -1044, "y" => 106, "z" => 1736)
			),
		),
    );

    /**
     * Returns the FlagData
     */
    public function getFlagData(){
        return $this->data;
    }

}


