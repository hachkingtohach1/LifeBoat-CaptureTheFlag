<?php

namespace CaptureTheFlag\task;

use pocketmine\utils\TextFormat;
use pocketmine\scheduler\PluginTask;

class CaptureTheFlagNotificationTick extends PluginTask
{
    protected $plugin;
    protected $game;
	protected $lastTick = 0;
	
    public function __construct($plugin, $gameManager) {
		$this->plugin = $plugin;
		$this->game = $gameManager;
		parent::__construct($plugin);
	}

    /**
     * Task runs 2 times in second
     */
    public function onRun($currentTick) {	
		/** Create player statistic message **/
		$blueKills = $this->game->getTeamKills("blue");
		$redKills = $this->game->getTeamKills("red");
		$blueCount = count($this->game->getTeamMembers("blue"));
		$redCount = count($this->game->getTeamMembers("red"));
		$blueFlags = 0;
		$redFlags = 0;
		if ($this->game->getPlacedBlocks("blue", "bluePlaced1")){
			$blueFlags++;
		}
		if ($this->game->getPlacedBlocks("blue", "bluePlaced2")){
			$blueFlags++;
		}
		if ($this->game->getPlacedBlocks("red", "redPlaced1")){
			$redFlags++;
		}
		if ($this->game->getPlacedBlocks("red", "redPlaced2")){
			$redFlags++;
		}
		
		/** Send notification to players **/
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
			if(!$player->isAuthorized() || $player->getTeam() == ""){
				continue;
			}

			/** Send notification of match starting **/
			if($this->game->getStartTimer() >= 0){
				if($this->game->getStartTimer() == 0){
					if($this->game->getStartTime() == 0){
						$player->sendLocalizedMessage("TOURNAMENT_START");
						$this->game->setStartTime(time());
					}
				} else {
					$player->sendLocalizedPopup("TOURNAMENT_COUNTDOWN", array($this->game->getStartTimer()));
				}
				continue;
			}		
			
			/** Send notification of match restarting **/
			if($this->game->getReinitTimer() >= 0){
				if($this->game->getReinitTimer() == 1){
					if($this->game->getStartTime() == 0){
						$player->sendLocalizedMessage("MATCH_RESTARTING");
						$this->game->setStartTime(time());
					}
				} else{
					$player->sendLocalizedPopup("RESTARTING_STATUS", array($this->game->getReinitTimer()));
				}
				continue;
			}

			if(!$this->game->getIsStart() && count($this->game->getInGamePlayers()) < 2){
				/** Send notification of more players needs to start **/
				$player->sendLocalizedPopup("LOW_PLAYERS");
			}else{
				/** Send notification of game statistic **/
				$Flags = $player->getTranslatedString("FLAGS");
				$Players = $player->getTranslatedString("PLAYERS");
				$Kills = $player->getTranslatedString("KILLS");
				$player->sendPopup(TextFormat::GRAY . $Flags." " . TextFormat::RED . $redFlags . TextFormat::GRAY . " - " . TextFormat::BLUE . $blueFlags . TextFormat::GRAY . " " .$Kills. " " . TextFormat::RED . $redKills . TextFormat::GRAY . " - " . TextFormat::BLUE . $blueKills . TextFormat::GRAY . " " .$Players. " " . TextFormat::RED . $redCount . TextFormat::GRAY . " - " . TextFormat::BLUE . $blueCount);
			}
		}
		$this->lastTick = time();
    }

}