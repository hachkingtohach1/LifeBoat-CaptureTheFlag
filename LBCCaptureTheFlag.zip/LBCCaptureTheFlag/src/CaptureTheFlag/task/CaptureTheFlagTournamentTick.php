<?php

namespace CaptureTheFlag\task;

use pocketmine\scheduler\PluginTask;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;

class CaptureTheFlagTournamentTick extends PluginTask
{
    protected $plugin;
    protected $game;
	protected $lastTick = 0;
	
    public function __construct($plugin, $gameManager) {
		$this->plugin = $plugin;
		$this->game = $gameManager;
		parent::__construct($plugin);
		/** lastTick contains time of last tick (in unixtime) **/
		$this->lastTick = time();
	}

    /**
     * Task runs every second
     */
    public function onRun($currentTick) {		
		if(!$this->game->getIsStart() && (count($this->game->getInGamePlayers()) >= 2)){
			$this->game->setIsStart(true);
			$this->game->runStartTimer();
		}
		
		/*
		 * Starts match and teleports players to their team spawnpoint
		 */
		if($this->lastTick != time()){
			if($this->game->getStartTimer() >= 0){
				if($this->game->getStartTimer() == 2){	
					$this->game->freezeGameMap();
					foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
						if($player->getTeam() != ""){
							$spawnPos = $this->game->getFlagData("spawnCoords", $player->getTeam());
							$spawnPos["x"] = $spawnPos["x"] + (rand(0,2) * pow(-1, rand(1,2)));
							$spawnPos["z"] = $spawnPos["z"] + (rand(0,2) * pow(-1, rand(1,2)));
							$player->setSpawn(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
							$player->teleport(new Vector3($spawnPos["x"], $spawnPos["y"], $spawnPos["z"]));
                            if($player->isVip()){
                                $player->giveVipKit();
                            }else{
                                $player->giveSpawnKit();
                            }
						}
					}
				}
				$this->game->decStartTimer();
			}
		}
		
		/*
		 * Restart the match
		 */
		if($this->lastTick != time()){
			if($this->game->getReinitTimer() >= 0){
				if($this->game->getReinitTimer() == 0){	
					$this->game->initGame();
				}
				$this->game->decReinitTimer();
			}
		}
		
		/** Every 3 seconds (Update players names)**/
		if($this->lastTick < time() && $this->lastTick % 3 == 0){
			foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
				if($player->isAuthorized()){
                    if ($player->getTeam() != "") {
                        $player->updateDisplayedName(constant('pocketmine\utils\TextFormat::' . strtoupper($player->getTeam())));
                    }else{
                        $player->updateDisplayedName(TextFormat::WHITE);
                    }
                }
                
			}
		}
		$this->lastTick = time();
    }
}