<?php

namespace CaptureTheFlag;

use pocketmine\item\Item;

class CaptureTheFlagPlayer extends \LbCore\player\LbPlayer {
	
	protected $vipKitGiven = false;
	protected $team = "";
    protected $particleHotbar = [1, 2, 3, 4];

    /**
     * Gives the initial spawn kit for the player without any VIP advantages.
     */
	public function giveSpawnKit() {
		$this->getInventory()->clearAll();
		$this->setHotbarItem(0, Item::get(Item::STONE_SWORD, 0, 1));
		$this->setHotbarItem(1, Item::get(Item::BREAD, 0, 16));
		$this->setHotbarItem(2, Item::get(Item::STONE_PICKAXE, 0, 1));
		$this->setHotbarItem(3, Item::get(Item::WOOD, 0, 32));
		$this->getInventory()->addItem(Item::get(Item::STONE_SHOVEL, 0, 1));
		$this->setStateInGame();
		$this->getInventory()->sendContents($this);
	}
	
	/**
     * Called after player logged in and has VIP or VIP+.
     */
    public function giveVipKit()
    {
		// VIP+
		if ($this->isVip() && $this->vipStatus === 'vip+') {
			$this->getInventory()->clearAll();

			$this->setHotbarItem(0, Item::get(Item::IRON_SWORD, 0, 1));
			$this->setHotbarItem(1, Item::get(Item::BOW, 0, 1));
			$this->setHotbarItem(2, Item::get(Item::ARROW, 0, 32));
			$this->setHotbarItem(3, Item::get(Item::BREAD, 0, 16));

			$this->setArmorItem(0, Item::get(Item::CHAIN_HELMET, 0, 1));
			$this->setArmorItem(1, Item::get(Item::CHAIN_CHESTPLATE, 0, 1));
			$this->setArmorItem(2, Item::get(Item::CHAIN_LEGGINGS, 0, 1));
			$this->setArmorItem(3, Item::get(Item::CHAIN_BOOTS, 0, 1));
			
			$this->getInventory()->addItem(Item::get(Item::WOOD, 0, 32));
			$this->getInventory()->addItem(Item::get(Item::IRON_SHOVEL, 0, 1));
			$this->getInventory()->addItem(Item::get(Item::IRON_PICKAXE, 0, 1));
			$this->vipKitGiven = true;
		//VIP
		} elseif($this->isVip() && $this->vipStatus === 'vip') {
			$this->getInventory()->clearAll();
			
			$this->setHotbarItem(0, Item::get(Item::STONE_SWORD, 0, 1));
			$this->setHotbarItem(1, Item::get(Item::STONE_PICKAXE, 0, 1));
			$this->setHotbarItem(2, Item::get(Item::STONE_SHOVEL, 0, 1));
			$this->setHotbarItem(3, Item::get(Item::BREAD, 0, 16));

			$this->setArmorItem(0, Item::get(Item::GOLD_HELMET, 0, 1));
			$this->setArmorItem(1, Item::get(Item::GOLD_CHESTPLATE, 0, 1));
			$this->setArmorItem(2, Item::get(Item::LEATHER_PANTS, 0, 1));
			$this->setArmorItem(3, Item::get(Item::LEATHER_BOOTS, 0, 1));
			
			$this->getInventory()->addItem(Item::get(Item::WOOD, 0, 32));
			$this->vipKitGiven = true;
		}
		$this->setStateInGame();
		$this->getInventory()->sendContents($this);
    }
	
	/**
	 * Sets armor for player and put it on at once
	 */
	public function setArmorItem($index, Item $item) {
		$this->getInventory()->setArmorItem($index, $item);
		$this->getInventory()->sendArmorContents($this);
	}
	
	/**
	 * Returns player's team
	 */
	public function getTeam(){
		return $this->team;
	}
	
	/*
	 * Set team for player
	 */
	public function setTeam($team){
		$this->team = $team;
	}
	
	/**
	 * Returns true if player is dead
	 */
	public function isDead(){
		return $this->dead;
	}
	
	/**
	 * Returns true if vip kit already given
	 */
	public function isVipKitGiven(){
		return $this->vipKitGiven;
	}
	
}
