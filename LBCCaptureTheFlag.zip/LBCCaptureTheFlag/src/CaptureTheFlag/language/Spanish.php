<?php
namespace CaptureTheFlag\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\Spanish as LbSpanish;
use LbCore\language\Translate;

/**
 * Translates in Spanish specific CtF messages
 */
class Spanish extends LbSpanish {
    
    public function __construct() {
        $this->translates = array_merge($this->translates, array(
            /* Login & Registration */
            "NEEDS_LOGIN" => TextFormat::GREEN."Por favor, inicia sesión para unirse a juego",
            "GAME_EXPLANATION" => TextFormat::YELLOW."Defiende habitaciones lana de su equipo, tratar de tender un\npuente hacia el otro lado para obtener la lana o conseguir mata.\n¡Divertirse!\n\n".TextFormat::BOLD.TextFormat::GREEN. "        <---  habitaciones de lana --->",
            "FLAG_EXPLANATION" => TextFormat::YELLOW."Capturar lana de oponerse a lado y lugar aquí!",
            /* Tournament */
            "WON_MATCH" => Translate::PREFIX_GAME_EVENT."arg1 ganó el juego.\n".Translate::PREFIX_GAME_EVENT."Regresando a la sala de espera...",
            "ALREADY_STARTED" => Translate::PREFIX_PLAYER_ACTION.TextFormat::LIGHT_PURPLE."El juego ya ha comenzado.",
            /** Commentary **/
            "FIRST_KILL" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." tuvo la primera matanza!",
            "SUCCESS_MSG_1" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." está acabando!",
            "SUCCESS_MSG_2" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." está ".TextFormat::BLUE."ganando".TextFormat::BLUE."!",
            "SUCCESS_MSG_3" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." está en una oleada de asesinatos!",
            "SUCCESS_MSG_4" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." lo esa haciendo muy bien!",
            /** Events **/
            "MATCH_RESTARTING" => Translate::PREFIX_GAME_EVENT.TextFormat::GOLD."Capturar la bandera ha terminado. Gracias por jugar!\n> Reiniciando el servidor...",
            "TOURNAMENT_COUNTDOWN" => TextFormat::DARK_AQUA."Juego se iniciará en arg1 segundo(s)",
			"TOURNAMENT_START" => TextFormat::GOLD."Capturar la bandera ha comenzado!",
            "USING_MAP" => Translate::PREFIX_GAME_EVENT.TextFormat::AQUA."bUsando el mapa: ".TextFormat::YELLOW."arg1",
            "USING_MAP_CREATOR" => Translate::PREFIX_GAME_EVENT."Usando el mapa: ".TextFormat::YELLOW."arg1".TextFormat::DARK_AQUA." by ".TextFormat::YELLOW."arg2",
            "CHEST_REFILL" => Translate::PREFIX_GAME_EVENT.TextFormat::YELLOW."Los cofres han sidos rellenados!",
            "RESTARTING_COUNTDOWN" => TextFormat::DARK_AQUA."Servidor de reiniciar en".TextFormat::YELLOW ." arg1".TextFormat::DARK_AQUA."...",
            "RESTARTING_STATUS" => "El servidor se reiniciará en arg1 segundos",
            "CANT_BREAK_BLOCK" => "No se puede romper bloques aquí",
			"CANT_PLACE_BLOCK" => "No se puede colocar bloques de aquí",
			/** Player actions **/
            "FULL" => TextFormat::RED."El juego está lleno.",
            "JOINING" => TextFormat::GREEN."Entrando al juego...",
            "WON_VIP" => "¡Has ganado artículos ".TextFormat::GOLD."VIParg1".TextFormat::GRAY." para esta partida! Para tener VIParg1 esto en cada juego, cómpralo en la sección que se llama Upgrades en el app de Lifeboat. ¡Buena suerte!",
            "TOURNAMENT_WELCOME" => TextFormat::AQUA."Bienvenido a Capturar la bandera!",
            "ON_JOIN" => Translate::PREFIX_GAME_EVENT."arg1 ".TextFormat::YELLOW."unido a la arg2 equipo.",
            "FIRST_FLAG" => Translate::PREFIX_GAME_EVENT."arg1 equipo capturó su primera bandera",
            "LOW_PLAYERS" => "A la espera de un jugador para comenzar partido.",
            "JOINED_TEAM" => "Te uniste al arg1 equipo.",
			"YOU_WERE_KILLED" => "Usted murieron a manos de arg1",
			"YOU_KILLED" => "Usted mató a arg1",
			/** In game messages **/
			"PLAYERS" => "Jugadores",
			"FLAGS" => "Banderas",
			"KILLS" => "Muertes",
            "LOGIN_BEFORE_JOIN" => TextFormat::RED . "Únicamente los jugadores pueden unirse a los mapas. Nombre de usuario está registrado. Por favor ingrese escribiendo su contraseña en el chat.",
            "REGISTER_BEFORE_JOIN" => TextFormat::RED . "Sólo los jugadores registrados pueden unirse mapas. Por favor regístrese escribiendo /register"
        ));
    }
}

