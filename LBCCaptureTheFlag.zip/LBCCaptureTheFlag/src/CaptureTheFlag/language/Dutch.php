<?php
namespace CaptureTheFlag\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\Dutch as LbDutch;
use LbCore\language\Translate;

/**
 * Translates in Dutch specific CtF messages
 */
class Dutch extends LbDutch {
    public function __construct() {
        $this->translates = array_merge($this->translates, array(
            /* Login & Registration */
            "NEEDS_LOGIN" => TextFormat::GREEN."Log in om het spel te sluiten",
            "GAME_EXPLANATION" => TextFormat::YELLOW."Wol kamers van je team te verdedigen, proberen te overbruggen\nnaar de andere kant om de wol te krijgen of krijgen kills.\nVeel plezier!\n\n".TextFormat::BOLD.TextFormat::GREEN. "          <---  Wol Kamers --->",
            "FLAG_EXPLANATION" => TextFormat::YELLOW."Vastleggen wol van tegenover elkaar en plaats hier!",
            /* Tournament */
            "WON_MATCH" => Translate::PREFIX_GAME_EVENT."arg1 heeft de match gewonnen.\n".Translate::PREFIX_GAME_EVENT."Terug naar de lobby...",
            "ALREADY_STARTED" => Translate::PREFIX_PLAYER_ACTION.TextFormat::LIGHT_PURPLE."Dat tournament is al begonnen.",
            /** Commentary **/
            "FIRST_KILL" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." heeft als eerste een speler vermoord!",
            "SUCCESS_MSG_1" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is op aan het ruimen",
            "SUCCESS_MSG_2" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is aan het ".TextFormat::BLUE."#winnen".TextFormat::GREEN."!",
            "SUCCESS_MSG_3" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." zit op een killing spree",
            "SUCCESS_MSG_4" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is lekker bezig",
            /** Events **/
            "MATCH_RESTARTING" => TextFormat::GOLD."Capture The Flag is beëindigd. Bedankt voor het spelen!\n> Server aan het herstarten...",
            "TOURNAMENT_COUNTDOWN" => TextFormat::DARK_AQUA."Spel zal starten in arg1 seconde(n)",
            "TOURNAMENT_START" => "§9>§f §6Capture the flag is begonnen!",
            "USING_MAP" => Translate::PREFIX_GAME_EVENT.TextFormat::AQUA."We gebruiken map: ".TextFormat::YELLOW."arg1",
            "USING_MAP_CREATOR" => Translate::PREFIX_GAME_EVENT."We gebruiken map: ".TextFormat::YELLOW."arg1".TextFormat::DARK_AQUA." door ".TextFormat::YELLOW."arg2",
            "CHEST_REFILL" => Translate::PREFIX_GAME_EVENT.TextFormat::YELLOW."Alle kisten zijn opnieuw gevuld!",
            "RESTARTING_COUNTDOWN" => TextFormat::DARK_AQUA."Server herstarten in".TextFormat::YELLOW ." arg1".TextFormat::DARK_AQUA."...",
            "RESTARTING_STATUS" => "De server wordt opnieuw opgestart in arg1 seconden",
            "CANT_BREAK_BLOCK" => "Je kunt hier geen blokken te breken",
			"CANT_PLACE_BLOCK" => "Je kunt hier geen blokken te plaatsen",
			/** Player actions **/
            "FULL" => TextFormat::RED."Dat tournament zit vol.",
            "JOINING" => TextFormat::GREEN."Match aan het joinen...",
            "WON_VIP" => "Je hebt ".TextFormat::GOLD."VIParg1".TextFormat::GRAY." gewonnen voor deze match! Om elke match VIParg1 items te ontvangen, unlock het in het Upgrades tabje in de lifeboat+ app. Succes!",
            "TOURNAMENT_WELCOME" => TextFormat::AQUA."bWelkom op de vlag Capture!",
            "ON_JOIN" => Translate::PREFIX_GAME_EVENT."arg1 ".TextFormat::YELLOW."toegetreden tot de arg2 team.",
            "FIRST_FLAG" => Translate::PREFIX_GAME_EVENT."arg1 team veroverde hun eerste vlag",
            "LOW_PLAYERS" => "Wachten voor een speler om te beginnen match.",
            "JOINED_TEAM" => "U toegetreden tot de arg1 team.",
			"YOU_WERE_KILLED" => "Je werd gedood door arg1",
			"YOU_KILLED" => "Je vermoord arg1",
			/** In game messages **/
			"PLAYERS" => "Spelers",
			"FLAGS" => "Vlaggen",
			"KILLS" => "Kills",
            "LOGIN_BEFORE_JOIN" => TextFormat::RED . "Alleen ingelogde spelers kunnen meedoen kaarten. Gebruikersnaam wordt geregistreerd. Gelieve in te loggen met het typen van uw wachtwoord in de chat.",
            "REGISTER_BEFORE_JOIN" => TextFormat::RED . "Alleen geregistreerde spelers kunnen meedoen kaarten. Kunt u zich inschrijven door het intikken van /register"
        ));
    }
}