<?php
namespace CaptureTheFlag\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\English as LbEnglish;
use LbCore\language\Translate;

/**
 * Translates in English specific CtF messages
 */
class English extends LbEnglish {
    
    public function __construct() {
        $this->translates = array_merge($this->translates, array(
            /* Login & Registration */
            "NEEDS_LOGIN" => TextFormat::GREEN."Please sign in to join game",
            "GAME_EXPLANATION" => TextFormat::YELLOW."Defend your team's wool rooms, try to bridge\nto the other side to get the wool or get kills.\nHave fun!\n\n".TextFormat::BOLD.TextFormat::GREEN. "          <---  Wool Rooms --->",
            "FLAG_EXPLANATION" => TextFormat::YELLOW."Capture wool from opposing side and place here!",
            /* Tournament */
            "WON_MATCH" => Translate::PREFIX_GAME_EVENT."arg1 won the match.",
            "ALREADY_STARTED" => Translate::PREFIX_PLAYER_ACTION.TextFormat::LIGHT_PURPLE."The game has already started.",
            /** Commentary **/
            "FIRST_KILL" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." got the first kill!",
            "SUCCESS_MSG_1" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is cleaning up!",
            "SUCCESS_MSG_2" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is ".TextFormat::BLUE."#winning".TextFormat::BLUE."!",
            "SUCCESS_MSG_3" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is on a killing spree!",
            "SUCCESS_MSG_4" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." is on a roll!",
            /** Events **/
            "MATCH_RESTARTING" => TextFormat::GOLD."Capture the flag has ended. Thanks for playing!\n> Restarting the server...",
            "TOURNAMENT_COUNTDOWN" => TextFormat::DARK_AQUA."Game will start in arg1 second(s)",
			"TOURNAMENT_START" => TextFormat::GOLD."Capture the flag has started!",
            "USING_MAP" => Translate::PREFIX_GAME_EVENT.TextFormat::AQUA."Using map: ".TextFormat::YELLOW."arg1",
            "USING_MAP_CREATOR" => Translate::PREFIX_GAME_EVENT."Using map: ".TextFormat::YELLOW."arg1".TextFormat::DARK_AQUA." by ".TextFormat::YELLOW."arg2",
            "CHEST_REFILL" => Translate::PREFIX_GAME_EVENT.TextFormat::YELLOW."All chests have been refilled!",
            "RESTARTING_COUNTDOWN" => TextFormat::DARK_AQUA."Server restarting in".TextFormat::YELLOW ." arg1".TextFormat::DARK_AQUA."...",
            "RESTARTING_STATUS" => "The server will restart in arg1 seconds",
            "CANT_BREAK_BLOCK" => "You can't break blocks here",
			"CANT_PLACE_BLOCK" => "You can't place blocks here",
			/** Player actions **/
            "FULL" => TextFormat::RED."That tournament is full.",
            "JOINING" => TextFormat::GREEN."Joining the match...",
            "WON_VIP" => "You won ".TextFormat::GOLD."VIParg1".TextFormat::GRAY." for this game!\nTo get VIParg1 items every game, unlock it in the Upgrades\ntab on the Lifeboat+ app. Good luck!",
            "TOURNAMENT_WELCOME" => TextFormat::AQUA."Welcome to Capture the Flag!",
            "ON_JOIN" => Translate::PREFIX_GAME_EVENT."arg1 ".TextFormat::YELLOW."joined the arg2 team.",
            "FIRST_FLAG" => Translate::PREFIX_GAME_EVENT."arg1 team captured their first flag",
            "LOW_PLAYERS" => "Waiting for one player to begin match.",
            "JOINED_TEAM" => "You joined the arg1 team.",
			"YOU_WERE_KILLED" => "You were killed by arg1",
			"YOU_KILLED" => "You killed arg1",
			/** In game messages **/
			"PLAYERS" => "Players",
			"FLAGS" => "Flags",
			"KILLS" => "Kills",
            "LOGIN_BEFORE_JOIN" => TextFormat::RED . "Only logged in players can join maps. Username is registered. Please log in by typing your password in chat.",
            "REGISTER_BEFORE_JOIN" => TextFormat::RED . "Only registered players can join maps. Please register by typing /register"
		));
    }
}