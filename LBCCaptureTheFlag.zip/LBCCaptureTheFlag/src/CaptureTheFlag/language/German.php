<?php
namespace CaptureTheFlag\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\German as LbGerman;
use LbCore\language\Translate;

/**
 * Translates in German specific CTF messages
 */
class German extends LbGerman {
    
    public function __construct() {
        $this->translates = array_merge($this->translates, array(
            /* Login & Registration */
            "NEEDS_LOGIN" => TextFormat::GREEN."Bitte loggen Sie sich ein Spiel beitreten",
            "GAME_EXPLANATION" => TextFormat::YELLOW."Verteidigen Wolle Zimmer Ihres Teams, versuchen Sie, auf die\nandere Seite überbrücken, die Wolle erhalten oder tötet.\nSpaß haben!\n\n".TextFormat::BOLD.TextFormat::GREEN. "          <---  Wolle Zimmer --->",
            "FLAG_EXPLANATION" => TextFormat::YELLOW."Crfassen Wolle von gegenüberliegenden Seiten und Ort hier!",
            /* Tournament */
            "WON_MATCH" => Translate::PREFIX_GAME_EVENT."arg1 Gewann das Spiel.\n".Translate::PREFIX_GAME_EVENT."Zur Lobby zurück kehren...",
            "ALREADY_STARTED" => "§dDieses Spiel hat bereits begonnen.",
            /** Commentary **/
            "FIRST_KILL" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN."hat den ersten Kill!",
            "SUCCESS_MSG_1" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." räumt auf!",
            "SUCCESS_MSG_2" =>  Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." ist am ".TextFormat::BLUE."Gewinnen".TextFormat::BLUE."!",
            "SUCCESS_MSG_3" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." hat eine Kill Serie!",
            "SUCCESS_MSG_4" => Translate::PREFIX_PLAYER_DEATH.TextFormat::WHITE."arg1".TextFormat::GREEN." hat einen lauf!",
            /** Events **/
            "MATCH_RESTARTING" => Translate::PREFIX_GAME_EVENT.TextFormat::GOLD."Erfassung das Flagge hat beendet. Danke fürs Spielen!\n> Server wird neugestartet...",
            "TOURNAMENT_COUNTDOWN" => TextFormat::DARK_AQUA."Spiel wird in 2 Sekunde(n) starten",
			"TOURNAMENT_START" => TextFormat::GOLD."Erfassung das Flagge hat gestartet",
            "USING_MAP" => Translate::PREFIX_GAME_EVENT.TextFormat::AQUA."Benutzte Map: ".TextFormat::YELLOW."arg1",
            "USING_MAP_CREATOR" => Translate::PREFIX_GAME_EVENT."Benutzte Map: ".TextFormat::YELLOW."arg1".TextFormat::DARK_AQUA." von ".TextFormat::YELLOW."arg2",
            "CHEST_REFILL" => Translate::PREFIX_GAME_EVENT.TextFormat::YELLOW."Alle Kisten wurden erneut gefüllt!!",
            "RESTARTING_COUNTDOWN" => TextFormat::DARK_AQUA."Server neu starten in".TextFormat::YELLOW ." arg1".TextFormat::DARK_AQUA."...",
            "RESTARTING_STATUS" => "wird der Server neu starten in arg1 sekunden",
            "CANT_BREAK_BLOCK" => "Sie können keine Blöcke hier brechen",
			"CANT_PLACE_BLOCK" => "Sie können keine Blöcke hier platzieren",
			/** Player actions **/
            "FULL" => TextFormat::RED."Dieses Spiel ist voll.",
            "JOINING" => TextFormat::GREEN."Betrete das Match...",
            "WON_VIP" => "Du hast ".TextFormat::GOLD."VIParg1".TextFormat::GRAY." gewonnen! Bekomme VIParg1 Items in jedem Spiel, schalte es in der \"Upgrade\" Leiste in der lifeboat+ app frei. Viel Glück!",
            "TOURNAMENT_WELCOME" => TextFormat::AQUA."Willkommen bei Erfassung das Flagge",
            "ON_JOIN" => Translate::PREFIX_GAME_EVENT."arg1 ".TextFormat::YELLOW."beigetreten das arg2 mannschaft.",
            "FIRST_FLAG" => Translate::PREFIX_GAME_EVENT."arg1 Mannschaft erobert ihr erstes flag",
            "LOW_PLAYERS" => "Warten auf einen Spieler, um Spiel beginnen.",
            "JOINED_TEAM" => "Sie schloss sich der arg1 mannschaft.",
			"YOU_WERE_KILLED" => "Sie wurden von arg1 getötet",
			"YOU_KILLED" => "Sie töteten arg1",
			/** In game messages **/
			"PLAYERS" => "Spieler",
			"FLAGS" => "Flags",
			"KILLS" => "Kills",
            "LOGIN_BEFORE_JOIN" => TextFormat::RED . "Nur eingeloggte Spieler können Maps betreten. Dein Benutzername ist registriert. Bitte melde dich an, indem du dein Passwort in den Chat schreibst.",
            "REGISTER_BEFORE_JOIN" => TextFormat::RED . "Nur registrierte Spieler können Maps betreten. Bitte registriere dich mit /register"
        ));
    }
}

