# LBCCaptureTheFlag
The CTF plugin/game using the common components from LBComponents
